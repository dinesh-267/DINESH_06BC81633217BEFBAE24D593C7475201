// ---------- FETCH & DISPLAY STOCK ----------
async function fetchStock() {
  const res = await fetch('/api/stock');
  const data = await res.json();
  const stockList = document.getElementById('stock-list');
  stockList.innerHTML = '';
  data.forEach(item => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.name}</td>
      <td>${item.quantity}</td>
      <td>
        <button class="stock-delete-btn" onclick="deleteStock('${item.name}')">Delete</button>
      </td>
    `;
    stockList.appendChild(row);
  });
}

// ---------- ADD STOCK ----------
document.getElementById('addStockBtn').addEventListener('click', async () => {
  const name = document.getElementById('stockName').value;
  const qty = parseInt(document.getElementById('stockQty').value, 10);
  await fetch('/api/stock/add', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, quantity: qty })
  });
  fetchStock();
});

// ---------- UPDATE STOCK ----------
document.getElementById('updateStockBtn').addEventListener('click', async () => {
  const name = document.getElementById('stockName').value;
  const qty = parseInt(document.getElementById('stockQty').value, 10);
  await fetch('/api/stock/update', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, quantity: qty })
  });
  fetchStock();
});

// ---------- DELETE STOCK ----------
async function deleteStock(name) {
  const confirmDelete = confirm(`Delete stock "${name}"?`);
  if (!confirmDelete) return;
  await fetch('/api/stock/delete', {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name })
  });
  fetchStock();
}

// ---------- FETCH ORDERS ----------
async function fetchOrders() {
  const res = await fetch('/api/orders');
  const data = await res.json();
  const list = document.getElementById('orders-list');
  list.innerHTML = '';
  data.forEach(order => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${order.product}</td>
      <td>${order.quantity}</td>
      <td>${order.customerName}</td>
      <td><button onclick="completeOrder('${order._id}')">Complete</button></td>
    `;
    list.appendChild(row);
  });
}

// ---------- FETCH COMPLETED ORDERS ----------
async function fetchCompleted() {
  const res = await fetch('/api/completed');
  const data = await res.json();
  const list = document.getElementById('completed-list');
  list.innerHTML = '';
  data.forEach(order => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${order.product}</td>
      <td>${order.quantity}</td>
      <td>${order.customerName}</td>
    `;
    list.appendChild(row);
  });
}

// ---------- COMPLETE ORDER ----------
async function completeOrder(orderId) {
  const response = await fetch(`/api/orders/${orderId}/complete`, {
    method: 'POST'
  });
  if (!response.ok) {
    const data = await response.json();
    alert('Error: ' + (data.error || 'Failed to complete order'));
  }
  fetchStock();
  fetchOrders();
  fetchCompleted();
}

// ---------- ADD ORDER ----------
document.getElementById('order-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = document.getElementById('chocolateName').value;
  const qty = parseInt(document.getElementById('quantity').value, 10);
  const customerName = document.getElementById('customerName').value;
  const phone = document.getElementById('phone').value;
  const address = document.getElementById('address').value;

  await fetch('/api/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, quantity: qty, customerName, phone, address })
  });

  fetchStock();
  fetchOrders();
});

// ---------- INIT ----------
fetchStock();
fetchOrders();
fetchCompleted();
