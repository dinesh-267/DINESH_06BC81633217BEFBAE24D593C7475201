require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');

const app = express();

/* ========================
   CONFIG
======================== */
const PORT = Number(process.env.PORT) || 3000;
const MONGO_URI =
  process.env.MONGO_URI || 'mongodb://127.0.0.1:27017';
const DB_NAME = process.env.DB_NAME || 'chocolate_factory';

/* ========================
   MIDDLEWARE
======================== */
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

/* ========================
   MONGODB CLIENT (IPv4 FIX)
======================== */
const client = new MongoClient(MONGO_URI, {
  maxPoolSize: 10,
  serverSelectionTimeoutMS: 10000,
  family: 4, //  FORCE IPv4 (fixes ::1 ECONNREFUSED on Windows)
});

let db, Stock, Orders, Completed;

/* ========================
   HELPERS
======================== */
function toInt(v) {
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) ? n : NaN;
}

function sanitizeName(name) {
  return (name || '').trim();
}

function stockNameFilter(name) {
  return { name: { $regex: `^${sanitizeName(name)}$`, $options: 'i' } };
}

/* ========================
   DB SEED
======================== */
async function seedIfEmpty() {
  const count = await Stock.estimatedDocumentCount();
  if (count === 0) {
    await Stock.insertMany([
      { name: 'Milk Chocolate', quantity: 100 },
      { name: 'Dark Chocolate', quantity: 80 },
      { name: 'White Chocolate', quantity: 60 },
    ]);
    console.log(' Seeded initial stock');
  }
}

/* ========================
   DB INIT
======================== */
async function initDB() {
  try {
    console.log(' Connecting to MongoDB...');
    await client.connect();

    db = client.db(DB_NAME);
    Stock = db.collection('stock');
    Orders = db.collection('orders');
    Completed = db.collection('completed');

    await Stock.createIndex({ name: 1 }, { unique: true }).catch(() => {});
    await Orders.createIndex({ createdAt: -1 }).catch(() => {});
    await Completed.createIndex({ createdAt: -1 }).catch(() => {});

    await seedIfEmpty();

    console.log(' Connected to MongoDB');
  } catch (err) {
    console.error(' MongoDB connection failed');
    console.error(err.message);
    process.exit(1);
  }
}

/* ========================
   ROUTES
======================== */
app.get('/api/health', (req, res) => {
  res.json({ ok: true, db: !!db, time: new Date().toISOString() });
});

app.get('/api/stock', async (req, res) => {
  try {
    const items = await Stock.find({}).sort({ name: 1 }).toArray();
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stock' });
  }
});

app.post('/api/stock/add', async (req, res) => {
  try {
    const name = sanitizeName(req.body.name);
    const qty = toInt(req.body.quantity);

    if (!name || Number.isNaN(qty)) {
      return res.status(400).json({ error: 'Invalid stock data' });
    }

    await Stock.updateOne(
      stockNameFilter(name),
      { $inc: { quantity: qty }, $set: { name } },
      { upsert: true }
    );

    const doc = await Stock.findOne(stockNameFilter(name));
    res.json({ message: 'Stock added/updated', item: doc });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add stock' });
  }
});

app.post('/api/stock/update', async (req, res) => {
  try {
    const name = sanitizeName(req.body.name);
    const qty = toInt(req.body.quantity);

    if (!name || Number.isNaN(qty) || qty < 0) {
      return res.status(400).json({ error: 'Invalid stock data' });
    }

    await Stock.updateOne(
      stockNameFilter(name),
      { $set: { quantity: qty, name } },
      { upsert: true }
    );

    const doc = await Stock.findOne(stockNameFilter(name));
    res.json({ message: 'Stock quantity set', item: doc });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update stock' });
  }
});

app.delete('/api/stock/delete', async (req, res) => {
  try {
    const name = sanitizeName(req.body.name);
    if (!name) return res.status(400).json({ error: 'No stock name provided' });

    const result = await Stock.deleteOne(stockNameFilter(name));
    res.json({
      message: result.deletedCount ? 'Deleted' : 'Not found',
      deletedCount: result.deletedCount,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete stock' });
  }
});

app.get('/api/orders', async (req, res) => {
  try {
    const items = await Orders.find({}).sort({ createdAt: -1 }).toArray();
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const name = sanitizeName(req.body.name);
    const qty = toInt(req.body.quantity);
    const customerName = sanitizeName(req.body.customerName);
    const phone = sanitizeName(req.body.phone);
    const address = (req.body.address || '').trim();

    if (!name || Number.isNaN(qty) || qty <= 0 || !customerName || !phone) {
      return res.status(400).json({ error: 'Invalid order data' });
    }

    const stockItem = await Stock.findOne(stockNameFilter(name));
    let status = 'pending';

    if (stockItem && stockItem.quantity >= qty) {
      await Stock.updateOne(stockNameFilter(name), {
        $inc: { quantity: -qty },
      });
      status = 'confirmed';
    }

    const newOrder = {
      product: stockItem ? stockItem.name : name,
      quantity: qty,
      customerName,
      phone,
      address,
      status,
      createdAt: new Date(),
    };

    const { insertedId } = await Orders.insertOne(newOrder);
    res.status(201).json({
      message:
        status === 'confirmed'
          ? 'Order placed & confirmed'
          : 'Order placed as pending',
      order: { _id: insertedId, ...newOrder },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to place order' });
  }
});

app.post('/api/orders/:id/complete', async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) return res.status(400).json({ error: 'Bad id' });

    const order = await Orders.findOne({ _id: new ObjectId(id) });
    if (!order) return res.status(404).json({ error: 'Order not found' });

    if (order.status === 'pending') {
      const stockItem = await Stock.findOne(stockNameFilter(order.product));
      if (!stockItem || stockItem.quantity < order.quantity) {
        return res.status(409).json({
          error: 'Insufficient stock to complete order',
        });
      }
      await Stock.updateOne(stockNameFilter(order.product), {
        $inc: { quantity: -order.quantity },
      });
    }

    await Orders.deleteOne({ _id: order._id });
    await Completed.insertOne({ ...order, completedAt: new Date() });

    res.json({ message: 'Order completed', completed: order });
  } catch (err) {
    res.status(500).json({ error: 'Failed to complete order' });
  }
});

app.get('/api/completed', async (req, res) => {
  try {
    const items = await Completed.find({})
      .sort({ createdAt: -1 })
      .toArray();
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch completed orders' });
  }
});

/* ========================
   START SERVER
======================== */
(async () => {
  await initDB();
  app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
})();
